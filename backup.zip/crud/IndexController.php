<?php
class IndexController extends Controller 
{
	
	
	public function action_index()
	{
		$model = new UserModel();
		$model->initConnection($this->config);
		$data = $model->getUsers();
		
		// По-идее - это заполняется тоже из базы
		$data["title"] = "Users List";
		
		$view = new MainPageView();
		$view->render($data);
		
		
	}
	
	
	
}

?>