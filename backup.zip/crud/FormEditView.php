<?php
class FormEditView extends View
{
	public function render($data)
	{
		
		
		echo "<h1>User Edit</h1>";
		
		echo "<form method=post>";
		echo "Name: <input type=text name=\"name\" value=\"".htmlspecialchars($data["name"])."\" /><br />";
		echo "Email: <input type=text name=\"email\" value=\"".htmlspecialchars($data["email"])."\" /><br />";
		echo "Age: <input type=text name=\"age\" value=\"".htmlspecialchars($data["age"])."\" /><br />";
		
		echo "Sex: <br />
		<input type=radio name=\"sex\" value=\"male\" ".(empty($data["sex"]) || $data["sex"]=="male" ? "checked" : "")."  />Male<br />
		<input type=radio name=\"sex\" value=\"female\" ".(!empty($data["sex"]) && $data["sex"]=="female" ? "checked" : "")." />Female<br />";
		
		
		echo "Race: <input type=text name=\"race\" value=\"".htmlspecialchars($data["race"])."\" /><br />";
		
		echo "Marriage: <input type=checkbox name=\"marriage\" ".(!empty($data["marriage"]) && $data["marriage"]=="1" ? "checked" : "")." value=\"1\" /><br />";
		
		echo "Skills: <input type=text name=\"skills\" value=\"".htmlspecialchars($data["age"])."\" /><br />";
		
		echo "Info RUS:<br />
		<textarea rows=\"10\" cols=\"45\" name=\"info_ru\">".htmlspecialchars($data["info_ru"])."</textarea><br />";
		echo "Info EN: <br />
		<textarea rows=\"10\" cols=\"45\" name=\"info_en\">".htmlspecialchars($data["info_en"])."</textarea><br /><br />";
		
		echo "<input type=\"hidden\" name=\"action\" value=\"do_edit\" />";
		echo "<button>Save</button>";
		echo "</form>";
			
			
	
			
		
	}
		
}


?>