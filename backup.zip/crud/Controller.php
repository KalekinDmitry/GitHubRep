<?php
abstract class Controller 
{
	protected $config = array();
	
	public function setConfig(array $config)
	{
		$this->config = $config;
	}
	
	
	public abstract function action_index();
	
	
	
	public function run()
	{
			$action = "index";
		
			if (!empty($_GET["route"]) && preg_match("~^[a-z_A-Z0-9]*/[a-z_A-Z0-9]*$~ui", $_GET["route"]))
			{
				$matches = explode("/", $_GET["route"]);
				
				
				if (!empty($matches[1]))
				{
					$action = $matches[1];
				}
			}
		
		$action = "action_".$action;
		
		// то же самое call_user_func($this, $action);
		$this->{$action}();
		
	}
		
	
}

?>