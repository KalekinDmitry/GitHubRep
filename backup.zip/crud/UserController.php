<?php
class UserController extends Controller
{
	
	
	public function action_index()
	{
		echo "Wrong Route for default index action";
	}
	
	
	public function action_edit()
	{
		
		$model = new UserModel();
		$model->initConnection($this->config);
	
		
		if (isset($_GET["id"])&&!empty($_GET["id"]))
		{
			
			if (isset($_POST["action"]) && $_POST["action"]=="do_edit")
			{
			// query_to_update record
			
				$model->updateOneUser($_POST, $_GET["id"]);
			}
			
			// try to read user data
			$data = $model->getOneUser($_GET["id"]);
			
				
		}
		
		
		$view = new FormEditView();
		$view->render($data);
		
		
		
		
	}
	
	
	
}

?>