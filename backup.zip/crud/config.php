<?php
//******CONFIG****************************************
$config["mysql_host"]  = 'localhost';
$config["mysql_user"]  = 'root';
$config["mysql_pwd"]   = '';
$config["mysql_db"]    = 'openprj';
// *********************************************
?>