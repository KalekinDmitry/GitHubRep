<?php
class RouteFactory
{
	public static function getController(array $config)
	{
		$controller = "index";
		
		if (isset($_GET["route"]))
		{
			$matches = explode("/", $_GET["route"]);
				
			if (!empty($matches[0]))
			{
				$controller = $matches[0]; // "user", "index"
			}
		
		}
		
		
		$controller = UCFirst($controller)."Controller";
		
		
		$controller = new $controller();
		$controller->setConfig($config);
		
		return $controller;
	}

}

?>