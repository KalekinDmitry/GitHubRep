<?php
class UserModel extends Model
{
	public function getUsers()
	{
		$q = "SELECT 
		tu.id,
		tu.name,
		tu.email,
		tu.age,
		tu.sex,
		tu.race,
		tu.marriage,
		tu.skills,
		ti.info_ru,
		ti.info_en
		FROM users tu 
		LEFT JOIN users_info ti ON tu.id=ti.id
		WHERE 1;";
		
    if ($mres = $this->db->query($q, MYSQLI_USE_RESULT))
    {
			
				while ($row = $mres->fetch_array(MYSQLI_ASSOC)) 
				{
					
							$result["users"][] = $row;
				}				
				
			
				$mres->close();		
    }
    
		
		
    return $result;	
		
	}
	
	public function getOneUser($id)
	{
			$q = "SELECT 
		tu.id,
		tu.name,
		tu.email,
		tu.age,
		tu.sex,
		tu.race,
		tu.marriage,
		tu.skills,
		ti.info_ru,
		ti.info_en
		FROM users tu 
		LEFT JOIN users_info ti ON tu.id=ti.id
		WHERE tu.id='".$this->db->real_escape_string($id)."'
		LIMIT 1;";
		
    if ($mres = $this->db->query($q, MYSQLI_USE_RESULT))
    {
			
				if ($row = $mres->fetch_array(MYSQLI_ASSOC)) 
				{
					
							$result = $row;
				}				
				
			
				$mres->close();		
    }
    
		
		
    return $result;	
		
	}
	
	public function updateOneUser($post, $id)
	{
		$q = "UPDATE  users  tu
		SET 
		tu.name 		= '".$this->db->real_escape_string($post["name"])."', 
		tu.email 		= '".$this->db->real_escape_string($post["email"])."', 
		tu.age			= '".$this->db->real_escape_string($post["age"])."', 
		tu.sex			= '".$this->db->real_escape_string($post["sex"])."', 
		tu.race			= '".$this->db->real_escape_string($post["race"])."', 
		tu.marriage	= '".$this->db->real_escape_string(!empty($post["marriage"]) ? 1 : 0)."', 
		tu.skills	= '".$this->db->real_escape_string($post["skills"])."'
		WHERE tu.id='".$this->db->real_escape_string($id)."'
		LIMIT 1;";
		
    if ($mres = $this->db->query($q, MYSQLI_USE_RESULT))
    {
			//$mres->close();		
    }
		
		$q = "UPDATE  users_info  tuinf
		SET 
		tuinf.info_ru 		= '".$this->db->real_escape_string($post["info_ru"])."', 
		tuinf.info_en		= '".$this->db->real_escape_string($post["info_en"])."' 
		WHERE tuinf.id='".$this->db->real_escape_string($id)."'
		LIMIT 1;";
		
    if ($mres = $this->db->query($q, MYSQLI_USE_RESULT))
    {
			//$mres->close();		
    }
    
		
		
	}
		
	
	
	
	
	
	
}
?>