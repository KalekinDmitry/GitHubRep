<?php
class Model
{
	protected $db = null;
	
	public function __construct()	
	{
				
	}
	
	public function initConnection($config)
	{
				$this->db =  mysqli_connect(
      $config["mysql_host"], 
      $config["mysql_user"], 
      $config["mysql_pwd"], 
      $config["mysql_db"]
			);
		
		if (!$this->db) 
		{
    echo("Error: Unable to connect to MySQL.");
    echo("Debugging errno: " . mysqli_connect_errno());
    echo("Debugging error: " . mysqli_connect_error());
    exit;
		}

		//  изменение набора символов на utf8 
		// SET character_set_client = charset_name;
		// SET character_set_results = charset_name;
		// SET character_set_connection = charset_name;
		// SET NAMES 'charset_name' COLLATE 'collation_name'
		if (!$this->db->set_charset("utf8")) 
		{
				echo("Ошибка при загрузке набора символов utf8: ".$this->db->error);
		} 
		else 
		{
				//echo("Текущий набор символов: ".$this->db->character_set_name());
		}
	
	
	}
	
}

?>