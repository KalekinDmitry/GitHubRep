<?php
class MainPageView extends View
{
	public function render($data)
	{
		echo "<h1>{$data["title"]}</h1>";
		
		echo "<table cellspacing=10 cellpadding=0>";			
		for ($i=0; $i<count($data["users"]); $i++)
		{
			echo "<tr>";			
			echo "
						
						<td>
							<b>".$data["users"][$i]["id"]."</b>
						</td>
						<td>
						Name:".$data["users"][$i]["name"].", email:".$data["users"][$i]["email"]."
						</td>
						
						<td>
						<form method=get>
						<input type=\"hidden\" name=\"route\" value=\"user/edit\" />
						<input type=\"hidden\" name=\"id\" value=\"".htmlspecialchars($data["users"][$i]["id"])."\" />
						<button>Edit</button>
						</form>
						</td>
						
						
						";
			echo "</tr>";			
		}
		echo "</table>";			
		
	}
		
}
?>