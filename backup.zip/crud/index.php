<?php
//preview.s4rk653p3bceg66rhhcvegp5mbrqw7b9sby4c4sul24ndn29.box.codeanywhere.com/crud/
require_once("./config.php");
require_once("./Controller.php");
require_once("./UserController.php");
require_once("./IndexController.php");
require_once("./RouteFactory.php");

require_once("./Model.php");
require_once("./UserModel.php");

require_once("./View.php");
require_once("./MainPageView.php");
require_once("./FormEditView.php");




$ctrl = RouteFactory::getController($config);
$ctrl->run();





?>