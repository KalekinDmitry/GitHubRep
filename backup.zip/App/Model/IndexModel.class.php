<?php
namespace App\Model;

// mysqli
// PDO

class IndexModel
{
		protected $db = null;
	
		public function __construct()
		{
			$this->initConnection();			
		}
	
	public function initConnection()
	{
			$reg = \Core\Registry::getInstance();
			$this->db = $reg["db"];	
	}
		
	
    public function create_database()
    {
        
      
    }
  
  public function getUsers()
  {
		// global $db;
		
    $result = array();
    
		
		// mysqli_query
		
		$q = "SELECT * FROM users WHERE 1;";
		
		echo $q;
		
    if ($mres = $this->db->query($q, MYSQLI_USE_RESULT))
    {
			
				while ($row = $mres->fetch_array(MYSQLI_ASSOC)) 
				{
					
							$result[] = $row;
				}				
				
			
				$mres->close();		
    }
    
		
		
    return $result;
		
		// serialize
		// unserialize
		// var_export -> PHP --> include
		
    
  }
  
}


?>