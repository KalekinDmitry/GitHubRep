<?php
namespace App\Controller;

class IndexController
{
  
  public function action_index()
  {
    echo "<h1>Index action</h1>";
    
    $model = new \App\Model\IndexModel();
    $data = $model->getUsers();
    
    
    
    vd($data);
    
  }
  
}
?>