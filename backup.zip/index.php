<?php
/****************************************************************************
*
*
*****************************************************************************/
// MUSTREAD
// http://getjump.me/ru-php-the-right-way/
// https://habrahabr.ru/post/12127/

// MUSTREAD Laravel
// https://habrahabr.ru/post/213933/
// https://habrahabr.ru/post/197454/
// https://habrahabr.ru/post/222453/

//REST
// https://habrahabr.ru/post/38730/

// Разобрать Laravel
// /https://laracasts.com/series/laravel-5-fundamentals
// https://www.youtube.com/playlist?list=P … VhTWo3DL9G
// http://jean179.ru/
// http://amegatron.ru/category/laravel/po … laravel-4/
// https://habrahabr.ru/post/213933/

// PHALCON
// https://habrahabr.ru/company/infopulse/blog/279461/


// Разобрать:
// https://habrahabr.ru/post/178859/
// http://pavlik.livejournal.com/36870.html
// https://habrahabr.ru/post/12127/


// https://codeanywhere.com/s/l/5ql7EHYmqJ4U0mK1D8Okjm4YlMNPTPftQ6XnCa6UloQNxosjy2qyFOqKsrnREYHv

// https://habrahabr.ru/post/183658/
// https://habrahabr.ru/sandbox/34795/ 
// http://vk-book.ru/primer-mvc-v-php-tretya-statya-modeli-rabota-s-bazoj-dannyx-sozdanie-chtenie-obnovlenie-i-udalenie-zapisej/
// http://iantonov.me/page/pishem-sobstvennyj-mvc-frejmvork-na-php




header('Content-Type: text/html; charset=utf-8');

require_once("./Core/load.php");
error_reporting(@$config["debug"]=='1' ? E_ALL : E_NONE);


// Расширение mysql не поддерживается, начиная с PHP 5.5 - банально в PHP 7 его уже нет
// Поэтому используется либо MySQLi или PDO
// Цепляемся к БД и сразу сохраняем линк к БД в реестре
$reg["db"] =  mysqli_connect(
      $reg["CFG"]["mysql_host"], 
      $reg["CFG"]["mysql_user"], 
      $reg["CFG"]["mysql_pwd"], 
      $reg["CFG"]["mysql_db"]
);

if (!$reg["db"]) {
    \Core\Debug\ErrorLogger::log("Error: Unable to connect to MySQL.");
    \Core\Debug\ErrorLogger::log("Debugging errno: " . mysqli_connect_errno());
    \Core\Debug\ErrorLogger::log("Debugging error: " . mysqli_connect_error());
    exit;
}

//  изменение набора символов на utf8 
// SET character_set_client = charset_name;
// SET character_set_results = charset_name;
// SET character_set_connection = charset_name;
// SET NAMES 'charset_name' COLLATE 'collation_name'
if (!$reg["db"]->set_charset("utf8")) 
{
    \Core\Debug\ErrorLogger::log("Ошибка при загрузке набора символов utf8: %s\n", $reg["db"]->error);
} else 
{
    \Core\Debug\ErrorLogger::log("Текущий набор символов: %s\n", $reg["db"]->character_set_name(), true);
}

\Core\Debug\ErrorLogger::log("Success: A proper connection to MySQL was made! The my_db database is great.", true);
\Core\Debug\ErrorLogger::log("Host information: " . mysqli_get_host_info($reg["db"]), true);



vd($_SERVER["REQUEST_URI"]);


$a = new \App\Controller\IndexController();
$a->action_index();

echo "Pri";

echo \Core\Debug\ErrorLogger::getLog();

mysqli_close($reg["db"]); // Закрываем линк к БД

?>  

if (true)
{
  echo "<div>";
  echo "<h1>{$my_var}</h1>";
  echo "<h1>{$my_var}</h1>";
  echo "<h1>{$my_var}</h1>";
  echo "<h1>{$my_var}</h1>";
  echo "<h1>{$my_var}</h1>";
  echo "<h1>{$my_var}</h1>";
  echo "</div>";
}
