<?php
namespace Core;

class Registry implements \ArrayAccess
{
  use \Core\Patterns\TSingleton;
  
  private $vars;
  
  function offsetExists($offset) 
  {

        return isset($this->vars[$offset]);

  }


  function offsetGet($offset) 
  {

        return $this->vars[$offset];
  }


  function offsetSet($offset, $value) 
  {
        $this->vars[$offset] = $value;
  }

  function offsetUnset($offset) 
  {
        unset($this->vars[$offset]);
  }
  
}

?>