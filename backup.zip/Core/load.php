<?php
/**
* Вывод отладочной информации о переменной
**/
function vd($s)
{
  echo "<pre style='color:#ff4040; font-weight: bold;'>";
  var_dump($s);
  echo "</pre>";
}

/**
* Функция автозагрузки. Вызывается автоматически всякий раз, когда класс, экземпляр которого создается - не найден
* Как раз то, что нам нужно - мы будем использовать эту возможность, чтобы namespace вёл на папку с расположением класса
* для быстрой ориентации по файловой структуре проекта
**/
function __autoload($class_name) 
{
        $path = getcwd();
  
  	    $class = str_replace('\\', '/', $class_name);
        $parts = explode("/", $class);

        if (empty($parts) )
        {
            return false;
        }

        // Я хочу грузить автоматически php-файлы:
        // c описанием интерфейсов - .interface.php
        // абстрактные классы - .abstract.php
        // примеси - .trait.php
        // и другие классы - .class.php
        if (preg_match ("/^I[A-Z]{1}(.*)/", $parts[count($parts)-1]))
        {
          $class .= ".interface.php";
        }
        else if (preg_match ("/^A[A-Z]{1}(.*)/", $parts[count($parts)-1]))
        {
          $class .= ".abstract.php";
        }
         else if (preg_match ("/^T[A-Z]{1}(.*)/", $parts[count($parts)-1]))
        {
          $class .= ".trait.php";
        }
        else
        {
          $class .= ".class.php";
        }

  
        $filename = $class;
        $file = $path."/".$filename;
  
     
        if (file_exists($file) == false) 
        {
                return false;
        }

        include_once($file);
}



$path = getcwd();                                 // получили текущую папку проекта
$config = parse_ini_file($path."/config.ini");    // прочитали конфиг-файл
$config["path"] = $path;                          // записали папку в конфиг-переменную

$reg = \Core\Registry::getInstance();             // создали реестр, чтобы использовать вместо глобальных переменных
$reg["CFG"] = $config;                            // записали конфиг в реестр









?>