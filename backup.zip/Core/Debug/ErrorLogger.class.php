<?php
namespace Core\Debug;

class ErrorLogger
{
		static $log = "<br />\n";
	
		public static function log($s, $ok_msg=false)
		{
			self::$log .= "<span style=\"color: ".($ok_msg ? "#008000":"#800000").";\">{$s}</span><br />\n";			
		}
	
	public static function getLog()
	{
		return self::$log;		
	}
}

?>